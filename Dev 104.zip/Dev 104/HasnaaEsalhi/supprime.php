<?php 
require 'database.php';
$id = $_POST['id'];
$stmt = $connexion->prepare("DELETE FROM users WHERE iduser=:id");
echo $stmt->execute([':id' => $id]);
header('location: index.php');
?>