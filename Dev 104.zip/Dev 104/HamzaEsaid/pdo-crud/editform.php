<?php
	include('connect.php');
	$id=$_GET['id'];
	$result = $db->prepare("SELECT * FROM tb_user WHERE id= :userid");
	$result->bindParam(':userid', $id);
	$result->execute();
	for($i=0; $row = $result->fetch(); $i++){
?>
<form action="edit.php" method="POST">
<input type="hidden" name="memids" value="<?php echo $id; ?>" />
Username<br>
<input type="text" name="username" value="<?php echo $row['username']; ?>" /><br>
Name<br>
<input type="text" name="name" value="<?php echo $row['name']; ?>" /><br>
Gender<br>
<input type="text" name="gender" value="<?php echo $row['gender']; ?>" /><br>
Address<br>
<input type="text" name="address" value="<?php echo $row['address']; ?>" /><br>
Password<br>
<input type="text" name="password" value="<?php echo $row['password']; ?>" /><br>
<input type="submit" value="Save" />
</form>
<?php
	}
?>