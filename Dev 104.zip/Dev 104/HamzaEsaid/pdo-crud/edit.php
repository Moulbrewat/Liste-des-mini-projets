<?php
// configuration
include('connect.php');

// new data
$userName = $_POST['username'];
$name = $_POST['name'];
$gender = $_POST['gender'];
$address = $_POST['address'];
$password = $_POST['password'];
$id = $_POST['memids'];
// query
$sql = "UPDATE tb_user 
        SET username=?, name=?,  gender=?, address=?, password=?
		WHERE id=?";
$q = $db->prepare($sql);
$q->execute(array($userName,$name,$gender,$address,$password,$id));
header("location: index.php");

?>