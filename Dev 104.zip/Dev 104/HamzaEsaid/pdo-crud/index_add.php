<?php
session_start();
?>
<?php
if( isset($_SESSION['ERRMSG_ARR']) && is_array($_SESSION['ERRMSG_ARR']) && count($_SESSION['ERRMSG_ARR']) >0 ) {
	echo '<ul style="padding:0; color:red;">';
	foreach($_SESSION['ERRMSG_ARR'] as $msg) {
		echo '<li>',$msg,'</li>'; 
	}
	echo '</ul>';
	unset($_SESSION['ERRMSG_ARR']);
}
?>
<form action="reg.php" method="POST">
User Name<br>
<input type="text" name="username" /><br>
Name<br>
<input type="text" name="name" /><br>
Gender<br>
<input type="text" name="gender" /><br>
Address<br>
<input type="text" name="address" /><br>
Password<br>
<input type="text" name="password" /><br>

<input type="submit" value="Save" />
</form>