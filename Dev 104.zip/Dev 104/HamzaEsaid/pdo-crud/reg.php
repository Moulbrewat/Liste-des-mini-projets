<?php
session_start();
$errmsg_arr = array();
$errflag = false;
// configuration
$dbhost 	= "localhost";
$dbname		= "sampledatabase";
$dbuser		= "root";
$dbpass		= "";

// database connection
$conn = new PDO("mysql:host=$dbhost;dbname=$dbname",$dbuser,$dbpass);

// new data

$userName = $_POST['username'];
$name = $_POST['name'];
$gender = $_POST['gender'];
$address = $_POST['address'];
$password = $_POST['password'];

if($userName == '') {
	$errmsg_arr[] = 'You must enter your Username';
	$errflag = true;
}
if($name == '') {
	$errmsg_arr[] = 'You must enter your Name';
	$errflag = true;
}
if($gender == '') {
	$errmsg_arr[] = 'You must enter your Gender';
	$errflag = true;
}
if($address == '') {
	$errmsg_arr[] = 'You must enter your Address';
	$errflag = true;
}
if($password == '') {
	$errmsg_arr[] = 'You must enter your Password';
	$errflag = true;
}
if($errflag) {
	$_SESSION['ERRMSG_ARR'] = $errmsg_arr;
	session_write_close();
	header("location: index_add.php");
	exit();
}
// query
$sql = "INSERT INTO tb_user (username,name,gender,address,password) VALUES (:sas,:asas,:asafs,:fsg,:pass)";
$q = $conn->prepare($sql);
$q->execute(array(':sas'=>$userName,':asas'=>$name,':asafs'=>$gender,':fsg'=>$address,':pass'=>$password));
header("location: index.php");


?>