<?php
session_start();

if (isset($_GET['logout'])) {
	unset($_SESSION['username']);
	header("location: index.php");
}

if (!isset($_SESSION['username'])) {
	header("location: index.php");
}

?>
<div style="text-align:center;margin-top:50px;font-family:arial;font-size:20px;">
	Congrats!<br>
	You've Been Successfully Logged<br>
	<a href="?logout">Déconnexion</a>
</div>