<?php
$pdo = new PDO('mysql:host=localhost;dbname=Instagram', 'root', '');
