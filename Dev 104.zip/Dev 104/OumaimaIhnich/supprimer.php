
<?php 
        require_once 'database.php';
        $sqlState = $pdo->prepare('DELETE FROM vetements WHERE idvetements=?');
    $sqlState->execute([$_GET['id']]);
    header('Location: afficher.php');
    ?>