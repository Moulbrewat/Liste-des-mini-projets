<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Ajouter</title>
</head>
<body>
    <?php 
        require_once 'database.php';
        include_once 'nav.php';
    ?>
    <div class="container my-4">
        <?php 
            if(isset($_POST['ajouter'])){
                $nom = htmlspecialchars($_POST['nom']);
                $taille    = htmlspecialchars($_POST['taille']);
                $prix    = htmlspecialchars($_POST['prix']);
                if(!empty($nom) && !empty($taille) && !empty($prix)&& isset($_FILES['image'])){
                    $tmpName = $_FILES['image'] ['tmp_name'];
                    $image = $_FILES['image']['name'];
                    move_uploaded_file($tmpName,'images/'.$image);
                    
                   $sqlState = $pdo->prepare('INSERT INTO vetements VALUES(null,?,?,?,?,?,?)');
                    $sqlState->execute([$nom,$taille,$prix, $image, $login,$password]);
                
                    header('Location: afficher.php');
                }else{
                    ?>
                    <div class="alert alert-danger" role="alert">
                        Required fields.
                    </div>
                    <?php
                }

            }
        ?>

        
          

           
    <form method="POST" enctype="multipart/form-data">
    <div class="mb-3">
            <label class="form-label">nom</label>
            <input type="text" class="form-control" name="nom">
        </div>

        <div class="mb-3">
            <label class="form-label">taille</label>
            <input type="text" class="form-control" name="taille">
        </div>

        <div class="mb-3">
            <label class="form-label">prix</label>
            <input type="text" class="form-control" name="prix">
        </div>

        <div class="mb-3">
            <label class="form-label">image</label>
            <input type="file" class="form-control" name="image">
        </div>

        <button type="submit" class="btn btn-primary" name="ajouter">Ajouter</button>
    </form>
    </div>
</body>
</html>