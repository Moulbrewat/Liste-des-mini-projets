<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>Document</title>
</head>
<body>
    <?php 
        
        require_once 'database.php';
        include_once 'nav.php';
           
           $sqlState = $pdo->prepare('SELECT * FROM vetements WHERE idvetements=?');
           $sqlState->execute([$_GET['id']]);
           $vetements = $sqlState->fetch(PDO::FETCH_OBJ);
           if(isset($_POST['MODIFIER'])){
                $idevetements = $_POST['idvetements'];
                $nom = $_POST['nom'];
                $taille = $_POST['taille'];
                $prix = $_POST['prix'];
            
                if(!empty($nom) && !empty($taille)&& !empty($prix) && isset($_FILES['image'])){
                    $tmpName = $_FILES['image']['tmp_Name'];
                    $image = $_FILES['image']['name'];
                    move_uploaded_file($tmpName, 'images/'.$image);
                    $sqlState = $pdo->prepare('UPDATE vetements  SET nom=?, taille=? ,prix=?,image=? WHERE idvetements=?');
                    $sqlState->execute([$nom,$taille,$prix, $image,$idvetements]);
                    header('location:afficher.php');
                
                }else{
                ?>
                 <div class="alert alert-danger" role="alert">
                         <span class='fw-bolder'>tous les champs sont obligatoires</span> 
                    </div>
                <?php
                }
            }
      
          
    ?>
    
    <div class="row g-3 align-items-center">
            <div class="border border-primary p-2 my-5 mx-auto w-75">
                <h4>Modifier catégorie</h4>
                <form method="post" enctype="multipart/form-data">
                            <label for="title" class="col-form-label">
                            idvetements
                            </label>
                    <input type="hidden" name="idvetements"  class="form-control" value="<?=$vetements->idvetements?>">
                        <div class="col-auto">
                            <label for="title" class="col-form-label">
                                nom 
                            </label>
                        </div>
                        <div class="col-auto">
                            <input type="text" id="title" name="nom" class="form-control"  value="<?= $vetements->nom?>">
                        </div>
                        <div class="col-auto">
                            <label for="title" class="col-form-label">
                                taille 
                            </label>
                        </div>
                        <div class="col-auto">
                            <input type="text" id="title" name="taille" class="form-control"  value="<?= $vetements->taille?>">
                        </div>
                        <div class="col-auto">
                            <label for="title" class="col-form-label">
                                prix 
                            </label>
                        </div>
                        <div class="col-auto">
                            <input type="text" id="title" name="prix" class="form-control"  value="<?= $vetements->prix?>">
                        </div>
                        <div class="col-auto">
                            <label for="title" class="col-form-label">
                                image 
                            </label>
                        </div>
                        
                        <div class="col-auto">
                            <input type="file"  name="image" class="form-control"  value="<?= $vetements->image?>">
                        </div>
                       
                       
                        <div class="con-auto">
                            <input class='btn btn-primary rounded-3 my-2' type="submit" value="Modifier" name="MODIFIER">
                        </div>
                </form>
            </div>
        </div>
</body>
</html>