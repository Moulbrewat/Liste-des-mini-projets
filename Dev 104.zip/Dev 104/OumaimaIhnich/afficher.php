<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>
    <?php 
        require_once 'database.php';
        include_once 'nav.php';
   
     

        $sqlState = $pdo->query('SELECT * FROM vetements');
       
        $vetements = $sqlState->fetchAll(PDO::FETCH_OBJ);
        
    ?>
 
<div class="container my-4 ">
<form>
  <div class="mb-3">
    <label  class="form-label">catégorie</label>
    <input type="text" class="form-control"  name="nomc">
    </div>
       <button type="submit" class="btn btn-info btn-sm"name="rechercher">recherche</button>
   </form>

</div>




    <div class="container my-4 ">
        <a href="ajouter.php" class='btn btn-success btn-sm link float-end mb-4'>Ajouter</a>

  
    
    <table class="table">
        <thead>
            <tr>
            <th scope="col">idvetements</th>
            <th scope="col">nom</th>
            <th scope="col">taille</th>
            <th scope="col">prix</th>
            <th scope="col">image</th>
            <th scope="col">actions</th>
            </tr>
        </thead>
        <tbody>
            <?php 
                foreach($vetements as $vetement){ ?>
                    <tr>
                        <td><?= $vetement->idvetements ?></td>
                        <td><?= $vetement->nom ?></td>
                        <td><?= $vetement->taille ?></td>
                        <td><?= $vetement->prix ?></td>
                        <td><img src="images/<?= $vetement->image ?>" width="50px"></td>
                        <td>
                        <a class="btn btn-danger "href="modifier.php?id=<?= $vetement->idvetements?>">Modifier</a>
                        <a class="btn btn-warning" onclick="return confirm('Voulez vous vraiment supprimer le catégorie ?')" href="supprimer.php?id= <?= $vetement->idvetements?>">Supprimer</a>
                        </td>

                        
                    </tr>
                    <?php 
                }
                    ?>   
        </tbody>
</table>
    </div>
</body>
</html>