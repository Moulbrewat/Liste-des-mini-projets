<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>Authentification</title>
</head>
<body>
    <?php 

        if(isset($_POST['connexion'])){
            $login = $_POST['login'];
            $password = $_POST['password'];

            if(!empty($login) && !empty($password)){
                require_once 'database.php';
                $sqlState = $pdo->prepare('SELECT * FROM vetements
                                            WHERE email=? AND passw=?
                    ');
                $sqlState->execute([$login,$password]);

                if($sqlState->rowCount()>=1){
                    session_start();
                    $_SESSION['user'] = $sqlState->fetch(PDO::FETCH_ASSOC);
                    header('location:afficher.php');
                }else{
                    echo "Erreur de login/mot de passe";
                }
            }else{
                echo "Veuillez saisir un login et un mot de passe.";
            }
        }
    ?>
     <div class="container my-4">
    <h3>Authentification</h3>
    <form method="post">
        <label class="form-label">email</label>
        <input class="form-control" type="text" name="login">
        <label class="form-label">Mot de passe</label>
        <input class="form-control  " type="password" name="password" >
        <button type="submit" class="btn btn-info  my-4" name="connexion">connexion</button>

    </form>
    </div>
</body>
</html>