<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css" integrity="sha384-DyZ88mC6Up2uqS4h/KRgHuoeGwBcD4Ng9SiP4dIRy0EXTlnuz47vAwmeGwVChigm" crossorigin="anonymous"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/connexion.css">
    <title>LOGIN</title>
</head>
<body>

    <?php 
    include_once '../include/nav.php' ;
        if(isset($_POST['signin'])) {
            header('location:../signin/signin.php');
        } 
        if (isset($_POST['connexion'])) {
            $user_name = $_POST['login'];
            $password = $_POST['password'];
            if (!empty($user_name) && !empty($password)) {
                $pdo = new PDO("mysql:host=localhost;dbname=movies","root","");
                $sqlstate = $pdo->prepare("SELECT * FROM users WHERE user_name=? AND password=?");
                $sqlstate->execute([$user_name,$password]);
                $_SESSION['user'] = $sqlstate->fetch(PDO::FETCH_ASSOC);
                if($sqlstate->rowCount() >= 1){
                    // session_start();
                    header('location: ../main.php ');
                } else {
                    ?>
                        <div class="error">
                        <p><b>NOTICE :</b> User Name Or Password Incorect.</p>
                    </div>
                    <?php
                }
            } else {
                ?>
                    <div class="error">
                        <p><b>NOTICE :</b> Tous les champs sont obligatoire.</p>
                    </div>
                <?php
            }
        } 
    ?>
    <div class="container">
        <h3>LOG IN</h3>
            <form method="post">
                <input type="text" name="login" placeholder="User Name"><br>
                <input type="password" name="password" class="pass" placeholder="Password">
                <span class="eye">
                <i class="fas fa-eye"></i>
                <i class="fa fa-eye-slash" style="display:none;"></i>
            </span>
            <br>
                <input type="submit" value="connexion" class="btn btn-connexion" name="connexion">
            </form>
        </div>
    </div>
    <?php include_once "../include/footer.php"?>
        <script>
            let eyeS = document.querySelector('.fas');
        let eyeN = document.querySelector('.fa');
        let pass = document.querySelector(".pass")
        eyeS.addEventListener("click",function() {
            eyeS.style.display = "none"
            eyeN.style.display = "contents"
            pass.setAttribute("type", "text")
        })
        eyeN.addEventListener("click",function() {
            eyeS.style.display = "contents"
            eyeN.style.display = "none"
            pass.setAttribute("type", "password")
        })
        </script>
</body>
</html>