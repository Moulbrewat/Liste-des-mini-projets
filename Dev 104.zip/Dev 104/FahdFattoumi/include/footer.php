        
        <footer style="margin: 2rem 1rem 0.5rem 2rem;">
            <h5>
            <i class="fa fa-copyright"></i> 
            <span>CopyRight 2.0.2</span>
            </h5>
        </footer>