<?php
session_start(); 
if (!empty($_SESSION['user'])) {
    ?> 
    <div class="container">
        <ul class="nav-bar">
        <li><h3><a href="ajouter/ajouter.php">ADD MOVIES</a></h3></li>
        <li><h2>TOP MOVIES LISTE</h3></li>
        <li><h4><a href="deconnexion/deconnexion.php">LOG OUT</a></h4></li>
    </ul>
    </div>
        <?php
} else {
    ?>
    <div class="nav-bar">
    <ul>
        <li><h2>TOP MOVIES LISTE</h3></li></li>
        <li>
            <form method="post">
                <input type="submit" value="SiGN IN" name="signin">
            </form>
        </li>
    </ul>
    </div>
    <?php 
}
?>