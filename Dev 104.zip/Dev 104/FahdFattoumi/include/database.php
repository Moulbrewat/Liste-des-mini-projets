<?php 
$pdo = new PDO("mysql:host=localhost;dbname=movies","root","");
?>