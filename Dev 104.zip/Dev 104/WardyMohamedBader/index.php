<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <title>INTERNATIONAL BRAND</title>
</head>
<body>
    <?php include_once 'include/database.php';?>
    <?php include_once 'include/nav.php';?>
    <div class="container">
      <div class="row g-3 align-items-center">
          
          <div class="border border-primary p-2 my-5 mx auto w-75">
              <?php
              $title ='';
          if (isset($_POST['ajouter'])){
            $title = htmlspecialchars($_POST['title']);                                        //$_POST ['title'];
            if(!empty($title)){
                $sqlState = $pdo->prepare("INSERT INTO items VALUES(null,?)");
                $result=$sqlState->execute([$title]);                // valeur sous forme d'un tableau.
                if($result==true){
                ?>
                <div class="alert alert-success" role="alert">
                     La marque<span class='fw-bolder'>
                          <?= $title?>
                       </span> est bien ajoutée.
                     </div>
                <?php
                    }
            }else{
                ?>
                 <div class="alert alert-danger" role="alert">
                     The <span class='fw-bolder'>title</span> is mandatory (required).
                     </div>
                <?php
            }
        }
          
          ?>
          <h4>Ajouter marque :</h4>
          <form method="post">
             
                    <div class="col-auto">
                       <label for="title" class="col-form-label">
                           Marque <span class="required">*</span>
                        </label>
                        </div>
                        <div class="col-auto">
                            <input type="text" id="title" name="title" class="form-control" aria-describedby="titleHelpInline">
                        </div>
                        <div class="col-auto">
                            <span id="titleHelpInline" class="form-text">
                            Le titre de la marque.
                            </span>
                        </div>
                        <div class="con-auto">
                            <input class='btn btn-primary rounded-3 my-2' type="submit" value="Ajouter" name="ajouter">
                        </div>
                    </div>
             </form>
          </div>
   
    </div>
    <?php
    $sqlState =$pdo->query("SELECT * FROM todo.items");
    $items = $sqlState->fetchAll(PDO::FETCH_OBJ);
    
    ?>
    <table class="table">
  <tbody>
      <?php
      foreach($items as $key => $item){
          ?>
        <tr>
          <td><span class="badge rounded-pill bg-primary"><?php echo $item->id?></td></span>
          <td><?php echo $item->title?></td>
          <td>
              <form method="post">
                  <input type="hidden" name="id" value="<?php echo $item->id ?>">
                  <input formaction="modifier.php" class='btn btn-success' type="submit" value="&#9998;" name="modiffier">
                  <input formaction="supprimer.php" class='btn btn-danger' type="submit" value="&#10006;" name="supprimer" onclick="return confirm('voulez vous vraiment supprimer <?php echo $item-> title ?> ???');">
              </form>
          </td>
        </tr>
          <?php
          
      }
      ?>
  
  </tbody>
    
</table>
  </div>
</body>
</html>