<nav class="navbar navbar-light bg-primary">
  <div class="container-fluid">
    <a class="navbar-brand mb-0 h1 text-center text-light w-100">Marques &#10087; </a>
  </div>
</nav>