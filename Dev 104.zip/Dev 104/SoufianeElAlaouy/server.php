<?php
session_start();


    $name = "";
    $adresse = "";
    $id = 0;
    $edit_state = false;


$db = mysqli_connect('localhost', 'root', '', 'crud');
if (isset($_POST['save'])) {
    $name = $_POST['name'];
    $adresse = $_POST['adresse'];

    $query = "INSERT INTO info (name, adresse) VALUES ('$name', '$adresse')";
    mysqli_query($db, $query);
    $_SESSION['msg'] = "le client a ajouter";
    header('location: 1.php');

}
$db = mysqli_connect('localhost', 'root', '', 'crud');
if (isset($_POST['update'])) {
    $name = mysqli_real_escape_string($db, $_POST['name']);
    $adresse = mysqli_real_escape_string($db, $_POST['adresse']);
    $id = mysqli_real_escape_string($db, $_POST['id']);


    mysqli_query($db, "UPDATE info SET name='$name', adresse='$adresse' WHERE id=$id");
    $_SESSION['msg'] = "client a modifier";
    header('location: 1.php');


}

if (isset($_GET['del'])) {
    $id = $_GET['del'];
    mysqli_query($db, "DELETE FROM info WHERE id=$id");
    $_SESSION['msg'] = "client a supprimer";
    header('location: 1.php');
}


$results = mysqli_query($db, "SELECT * FROM info");






?>