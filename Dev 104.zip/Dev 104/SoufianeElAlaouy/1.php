
<?php include('server.php'); 

if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $edit_state = true;
    $rec = mysqli_query($db, "SELECT * FROM info WHERE id=$id");
    $record = mysqli_fetch_array($rec);
    $name =$record['name'];
    $adresse = $record['adresse'];
    $id = $record['id'];

}



?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <title> Gestion client</title>
    <link rel="stylesheet" href="style.css">
    
</head>
<body>
    <?php if (isset($_SESSION['msg'])): ?>
        <div class="msg">
            <?php 
            echo $_SESSION['msg'];
            unset($_SESSION['msg']);
            ?>
        </div>

    <?php endif ?>


    <table> 
        <thead>
            
            <th>Name</th>
            <th>Email</th>
        </thead>
        <tbody>
            <?php while ($row = mysqli_fetch_array($results)) { ?>
                <tr>
                <td><?php echo $row['name']; ?></td>
                <td><?php echo $row['adresse']; ?></td>
                <td>
                    <a class="edit_btn" href="1.php?edit=<?php echo $row['id']; ?>">modifier</a>
                </td>
                <td>
                    <a class="del_btn" href="server.php?del=<?php echo $row['id']; ?> ">supprimer</a>
                </td>
            </tr>

           <?php } ?>
            
        </tbody>
    </table>

   <form method="POST" action="server.php">
    <input type="hidden" name="id" value="<?php echo $id; ?>">
       <div class="input-group">
           <label>Name</label>
           <input type="text" name="name" value="<?php echo $name; ?>">
       </div>
       <div class="input-group">
           <label>Email</label>
           <input type="email" name="adresse" value="<?php echo $adresse; ?>">
       </div>
       <div class="input-group">
        <?php if($edit_state == false): ?> 
            <button type="submit" class="btn" name="save">Ajouter</button>
        <?php else: ?>
            <button type="submit" class="btn" name="update">Modification </button>

        <?php endif ?>


          
       </div>
   </form>
    
</body>
</html>