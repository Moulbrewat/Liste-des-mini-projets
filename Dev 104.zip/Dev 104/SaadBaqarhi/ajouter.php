<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscription</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <div class="container-fluid">
    <h1>S’inscrire</h1>
    <h2>C’est rapide et facile.</h2>
    <?php 
        if(isset($_POST['ajouter'])){
            $prenom = $_POST['prenom'];
            $nom    = $_POST['nom'];
            $email  = $_POST['email'];
            $password= $_POST['password'];
            $jour = $_POST['jour'];
            $mois = $_POST['mois'];
            $annee = $_POST['annee'];
            $genre = @$_POST['genre'];

            if(!empty($prenom) && !empty($nom) && !empty($email)
                && !empty($password) && !empty($jour) && !empty($mois)
                && !empty($annee) && !empty($genre)
            ){
                echo "Prenom : $prenom , .....";
            }
            else{
                ?>
                <span class="error">
                           Tous les champs sont obligatoires.
                       </span>
                <?php
            }

        }

    ?>
    <form method="post">
    <input type="text" name="prenom" placeholder="Prenom">
    <input type="text" name="nom" placeholder="Nom de famille">
    <input type="email" name="email" placeholder="Email">
    <input type="password" name="password" placeholder="Mot de passe">
    <label>Date de naissance</label>
    <select name="jour">
        <?php 
            for($i=1;$i<=31;$i++){
                ?>
                <option value="<?= $i?>"><?= $i?></option>
                <?php
            }
        ?>
    </select>
    <?php 
        $mois = ['Janvier','Février','Mars','Avril','Mai','Juin','Juillet','Aôut','Septembre','Novembre','Décembre'];
    ?>
    <select name="mois">
        <?php 
            foreach($mois as $key=>$val){
                ?>
                <option value="<?= $val?>"><?= $val?></option>
                <?php
            }
        ?>
        <option value="Janvier">Janvier</option>
    </select>
    <select name="annee">
        <?php 
            for($i=date('Y');$i>=1905;$i--){
                ?>
                <option value="<?= $i ?>"><?= $i ?></option>
                <?php
            }
        ?>
    </select>
    <br>
    <label>
        Genre
    </label>
    <br>
    <label for="homme">Homme</label>
    <input class="radio" type="radio" name="genre" id="homme" value="Homme">
    <label for="femme">Femme</label>

    <input class="radio" type="radio" name="genre" id="femme" value="Femme">
    <p>
    En appuyant sur S’inscrire, vous acceptez nos Conditions générales, notre Politique d’utilisation des données et notre Politique d’utilisation des cookies. Vous recevrez peut-être des notifications par texto de notre part et vous pouvez à tout moment vous désabonner.
    </p>
    <input type="submit" value="Ajouter" class='btn btn-success' name='ajouter'>
    </form>

    </div>
</body>

</html>