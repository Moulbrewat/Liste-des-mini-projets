<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Authentification</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <div class="container">

        <div class='left-section'>
            <img src="image/tiktok.PNG" alt="image/tiktok.PNG">
            <h3> Avec TIKTOK , partagez et restez en contact avec votre entourage.</h3>
        </div>
        
        <div class='right-section'>
            <?php 
                if(isset($_POST['connexion'])){
                   $email = $_POST['email'];
                   $password = $_POST['password'];
                   if(!empty($email) && !empty($password)){
                    ////.....
                    // SELECT * FROM users WHERE email='$email' AND password='$password'
                    //echo "Email : $email , Pass : $password";
                   }else{
                       ?>
                       <span class="error">
                           Tous les champs sont obligatoires.
                       </span>
                       <?php
                   }
                }
            ?>
            <form method="post">
                <input type="email" placeholder="Email" name="email">
                <input type="password" placeholder="Mot de passe" name="password">
                <input class='btn btn-primary' name="connexion" type="submit" value="Connexion">
                <a href="#">Mot de passe oublié ?</a>
            </form>
            <hr>
            <a class='btn btn-success' href="ajouter.php">Créer un nouveau compte</a>
            <h5>
                <a href="">Créer une Page </a> pour une célébrité, une marque ou une entreprise.
                </h6>
        </div>

    </div>

</body>

</html> 