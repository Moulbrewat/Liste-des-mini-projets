<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <title>Do What Excites</title>
</head>
<body>
    <div style="height:100vh;display:flex">
        <div
            class="container-1"
            style="
                max-width:50%;
                width:50%;
                background-image:url('m.jpg');
                background-size:cover;
                background-position:Genter;
            "
            >
        </div>
        <div class="container"style="width:50%;max-width:50%;background-color:black;">
            <h1>DO WHAT EXCITES</h1>
            <h2></h2>
            <form method="Post" class="p-5 text-light">
                <?php
                    if(isset($_POST['btn'])){
                        $db   =  new PDO('mysql:host=localhost;dbname=login','root','');
                        $sql = $db->prepare('SELECT * FROM email WHERE email=? AND password=?');
                         $sql->execute([$_POST['email'],$_POST['password']]);
                        $data = $sql->fetch(PDO::FETCH_ASSOC);
                        if($sql->rowCount() >=1){
                            session_start();
                            $_SESSION['CC']= $sql->fetch(PDO::FETCH_ASSOC);
                            header('location:index.php');
                        }
                        }
                ?>
                <div class="mb-2">
                    <label class="form-label">Email</label>
                    <input name="email" type="email" class="form-control">
                </div>
                <div class="mb-2">
                    <label class="form-label">Password</label>
                    <input name="password" type="password" class="form-control" id="exampleInputPassword1">
                </div>
                <button type="submit" name="btn" class="btn btn-outline-light form-control mb-2">Login</button>
                <span class="reg">if u don't have an acc create one, <a href="register.php" class="text-info">create account</a></span>
            </form>
        </div>
    </div>
    
</body>
</html>