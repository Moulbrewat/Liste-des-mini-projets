<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    <title>Add</title>
    <style>
        form{
            width: 90%;
        }
    </style>
</head>
<body class="bg-dark text-light">
    <?php  
        include_once('navbar.php');
        ?>
<div class="d-flex justify-content-center">
        <div>
            <h1 class="text-light text-center ">edit</h1>
            <form method="post" class="p-5 text-light">
                <?php 
                $image = 'unknown.png';
                    if(isset($_POST['submit'])){
                        if(!empty($_POST['title']) && !empty($_POST['prix'])){
                            $db = new PDO('mysql:host=localhost;dbname=yassine','root','');
                            $sql = $db->prepare('UPDATE cart SET title=?,prix=? WHERE id=?');
                            $data = $sql->execute([$_POST['title'],$_POST['prix'],$_SESSION['id']]);
                                header('location:index.php');
                        }
                    }
                ?>
                <div class="mb-2">
                    <label class="form-label">Title</label>
                    <input type="text" name="title" class="form-control">
                </div>
                <div class="mb-3">
                    <label class="form-label">Price (DH)</label>
                    <input type="number" name="prix" class="form-control">
                </div>
                <div class="mb-3">
                    <input type="file" accept="image/*" class="form-control">
                </div>
                <button type="submit" name="submit" class="btn btn-outline-light form-control mb-2">Add</button>
            </form>
        </div>
    </div>
</body>
</html>