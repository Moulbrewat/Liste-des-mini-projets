<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style2.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>
    <?php
    $db   =  new PDO('mysql:host=localhost;dbname=yassine','root','');
        $sql = $db->query('SELECT * FROM cart');
        $sql->execute();
        $data = $sql->fetchAll(PDO::FETCH_ASSOC);
        include_once('navbar.php');
        ?>
    <div class="header">

  <h1>DO WHAT EXCITES</h1>
  <p></p>
</div>

    <div class="d-grid gap-2 d-md-flex justify-content-md-end p-3">
        <form action="">
        <button formaction="add.php" class="btn btn-success me-md-2">Add</button>
        </form>
    </div>
<div class="container ">
<div class="row d-flex justify-content-center p-3">
    <?php 
        foreach($data as $cloths){
            $_SESSION['id'] = $cloths['id'];
            ?>
                <div class="card1 col-md-4 &aé& p-2">
                    <img src="<?=$cloths['img']?>" class="card-img-top">
                    <div class="card-body">
                    <h5 class="card-title text-center p-3"><?= $cloths['title']?></h5>
                    <h5 class="card-title text-center p-3"><?= $cloths['prix']?>DH</h5>
                    <div class="row text-light">
                        <form method="Post" class="row">
                            <?php 
                                if(isset($_POST['delete'])){
                                    $db = new PDO('mysql:host=localhost;dbname=yassine','root','');
                                    $sql = $db->prepare('DELETE FROM cart WHERE id=?');
                                    $data = $sql->execute([$_POST['hidden']]);
                                    if($data == true){
                                        header('location:index.php');
                                    }
                                }
                            ?>
                            <div class="col-md-6">
                                <input type="hidden" name="hidden" value="<?= $cloths['id']?>">
                            <button formaction="edit.php" class="form-control bg-info text-light">Modify</button>
                            </div>
                            <div class="col-md-6">
                            <button href="#" name="delete" class="form-control bg-danger text-light">Delete</button>
                            </div>
                        </form>
                
                        </div>
                    </div>
                </div>
            <?php
        }
    ?>
</div>
</div>
</body>
</html>