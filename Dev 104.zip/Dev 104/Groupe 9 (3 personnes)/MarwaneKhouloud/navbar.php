        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="#"></a>
        <div class="collapse navbar-collapse" id="navbarText">
        <ul class="navbar-nav m-auto">
            <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="#">Home</a>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="#">Features</a>
            </li>
        </ul>
            <?php 
    session_start();
                if(isset($_SESSION['CC'])){
                    ?>
                    <form method="POST">
                        <input formaction="logout.php" class="btn btn-warning" type="submit" value="log-out">
                    <?php
                }else{
                    ?>
                        <input formaction="login.php" class="btn btn-warning" type="submit" value="login">
                    </form>
                    <?php
                }
            ?>
        </div>
    </div>
    </nav>