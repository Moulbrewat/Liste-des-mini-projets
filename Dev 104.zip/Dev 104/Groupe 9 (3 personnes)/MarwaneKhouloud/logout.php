<?php

session_start(); 
if(isset($_SESSION['CC'])){
    
session_destroy();
header('location:login.php');
}