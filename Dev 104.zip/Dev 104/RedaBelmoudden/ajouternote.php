<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>inscription</title>
    <style>
      .o{
        text-align: center;
      }
    </style>
</head>
<body>
    <?php
        require_once 'database.php';
        include 'nav.php';
        
    ?>
    


    <?php
            if(isset($_POST['submit'])){

                $nom=$_POST['nom'];

                $prenom=$_POST['prenom'];

                $note=$_POST['note'];

                $resultat=$_POST['resultat'];

              

                 if(!empty($nom)&&!empty($prenom)&&!empty( $note)&&!empty( $resultat)){
                    $sqlstate= $pdo->prepare('INSERT INTO stagaire VALUES(null,?,?,?,?)');
                    $sqlstate->execute([$nom,$prenom, $note,$resultat]);
                    header('location:affichage.php');
                 }else{ ?>
                      <h5  class="o"  >tous les champs est obligatoire</h5>
                <?php }
            }?>
    
    




















<form method="POST" class="form-control">
  <div class="mb-3 mt-3">
    <label for="nom" class="form-label">nom:</label>
    <input type="text" class="form-control" id="nom" placeholder="Entrer nom de stagaire" name="nom">
  </div>
  <div class="mb-3 mt-3">
    <label for="prenom" class="form-label">prenom:</label>
    <input type="text" class="form-control" id="prenom" placeholder="Entrer prenom de stagaire" name="prenom">
  </div>
  <div class="mb-3">
    <label for="email" class="form-label">note</label>
    <input type="text" class="form-control"  placeholder="Entrer la note" name="note">
  </div>
  <div class="mb-3">
    <label for="pwd" class="form-label">resultat</label>
    <input type="text" class="form-control"  placeholder="Entrer resultat " name="resultat">
  </div>
  
  
  </div>
  <button type="submit" class="btn btn-primary" name="submit">ajouter la note de  stagiaire</button>
</form>
</body>
</html>