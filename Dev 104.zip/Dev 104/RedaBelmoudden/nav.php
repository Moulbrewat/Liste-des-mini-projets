<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
ul {
  list-style-type: none;
  margin: 0;
  padding: 10px;
  overflow: hidden;
  border: none;
}

li {
  float: right;
}

li a {
  
  
  font-weight: bolder;
  color: black;
  font-style: oblique;
  text-align: center;
  padding: 19px;
  text-decoration: none;
  
  
}
li a:hover{
  text-decoration: underline;
  
  
  
}




</style>
</head>
<body>

 <ul class="snip1143">
<?php 
        if(isset($_SESSION['user'])){
            ?>
      
   
    <li><a href="espaceformateur.php" >Acceuil</a></li>

    <li><a href="deconnexion.php" >deconnexion</a></li>

                
            <?php
        }else{
    ?>

    <li><a href="inscription.php" >inscription</a></li>
 <?php
        }
    ?>
 </ul>





</body>
</html>