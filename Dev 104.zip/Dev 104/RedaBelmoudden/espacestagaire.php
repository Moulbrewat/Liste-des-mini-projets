<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Espace Formateur </title>
    <style>
        .h1{
            text-align: center;
            
        }
        a{
            text-decoration: none;
            
            padding-left: 15px;
            font-weight: bold;
            
        }
        a:hover{
            
            color: black;
            
        }
        .y{
            text-align: center;
            

        }
    </style>
</head>
<body  style=" background-image: linear-gradient(to right, yellow , royalblue);">
    <?php
    include 'database.php';
    $sqlstate=$pdo->prepare('SELECT resultat FROM stagaire WHERE nom=?');
    $sqlstate->execute([$_SESSION['user']['nom']]);
    $result=$sqlstate->fetch(PDO::FETCH_OBJ);
        
        //session_start(); ?>



    <a href="deconnexionn.php" >deconnexion</a>

       <h1 class="h1"> <?php echo "Bienvenue  ". $_SESSION['user']['nom'];?>  </h1>

       <?php
          foreach($result as $r){?>
                <br><br><br><h1 class="y"> votre est resultat est : </h1> <br> <h1 class="y"><?= $r  ;?></h1>

              

         <?php }?>

      
       
       
       
      
       
           

                

          
       
       





   
  
    

</div>



        
    
    
    
</body>
</html>