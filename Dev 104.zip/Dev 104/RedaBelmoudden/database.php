<?php
     session_start(); 
    $pdo=new PDO('mysql:host=localhost;dbname=admins','root','');

    

?>