<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>
<body>

 
    



    <div class="header">
<?php

      
      require_once 'database.php';
    
    
    ?>





<?php

  if(isset($_POST['ok'])){
    $email=$_POST['email'];
    $password=$_POST['password'];
    if(!empty($email)&&!empty($password)){
      $sqlstate=$pdo->prepare('SELECT * FROM formateur WHERE  email=? AND password=? ');
      $sqlstate->execute([$email,$password]);
      $count=$sqlstate->rowCount();
      if($count>=1){
        $c=$sqlstate->fetch(PDO::FETCH_ASSOC);
        //session_start();
        $_SESSION['user']=$c;
        header('location:espaceformateur.php');

      }else{
        echo "Invalid login or password.";
      } 

    }
  }


?>
        <!--Content before waves-->
        <div class="inner-header flex">
        <!--Just the logo.. Don't mind this-->
        <svg version="1.1" class="logo" baseProfile="tiny" id="Layer_1" xmlns="http://www.w3.org/2000/svg"
        xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 500 500" xml:space="preserve">
        <path fill="#FFFFFF" stroke="#000000" stroke-width="10" stroke-miterlimit="10" d="M57,283" />
        
        </svg>
        
        <div class="main">
            <p class="sign" >Sign in</p>
            <form class="form1" method="POST">
                <input class="un " type="text"  placeholder="Username" name="email">
                <input class="pass" type="password"  placeholder="Password" name="password">
                <input type="submit" value="Sign in" name="ok" class="submit">
                <p class="forgot" ><a href="inscription.php" >inscription</p>
                
                
                    
                        
            </div>
             
        </div>
        

<script src="https://cdnjs.cloudflare.com/ajax/libs/animejs/2.0.2/anime.min.js"></script>
        
        <!--Waves Container-->
        <div>
        <svg class="waves" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
        viewBox="0 24 150 28" preserveAspectRatio="none" shape-rendering="auto">
        <defs>
        <path id="gentle-wave" d="M-160 44c30 0 58-18 88-18s 58 18 88 18 58-18 88-18 58 18 88 18 v44h-352z" />
        </defs>
        <g class="parallax">
        <use xlink:href="#gentle-wave" x="48" y="0" fill="rgba(255,255,255,0.7" />
        <use xlink:href="#gentle-wave" x="48" y="3" fill="rgba(255,255,255,0.5)" />
        <use xlink:href="#gentle-wave" x="48" y="5" fill="rgba(255,255,255,0.3)" />
        <use xlink:href="#gentle-wave" x="48" y="7" fill="#fff" />
        </g>
        </svg>
        </div>
        <!--Waves end-->
        
        </div>
        
</body>
</html>