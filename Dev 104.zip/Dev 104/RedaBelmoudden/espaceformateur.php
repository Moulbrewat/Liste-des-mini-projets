<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Espace Formateur </title>
    <style>
        .h1{
            text-align: center;
            color: lemonchiffon;
        }
        a{
            text-decoration: none;
            color: lemonchiffon;
            padding-left: 15px;
            font-weight: bold;
            
        }
        a:hover{
            
            color: black;
        }
    </style>
</head>
<body style=" background-image: linear-gradient(to right, blue , green);">
    <?php
        
        session_start(); ?>



<a href="deconnexion.php" >deconnexion</a>

       <h1 class="h1"> <?php echo "Bienvenue  ". $_SESSION['user']['nom'];?>  </h1>





       <div class="row row-cols-1 row-cols-md-2 g-4 m-5 p-5">
  <div class="col">
    <div class="card">
      <img src="g.jpg" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Ajouter</h5>
        <p class="card-text">ajouter la note de stagaire.</p>
        <a href="ajouternote.php" class="btn btn-success">Ajouter</a>
      </div>
    </div>
  </div>
  <div class="col">
    <div class="card">
      <img src="j.jpg" class="card-img-top"   style="height:398px ;" alt="...">
      <div class="card-body">
        <h5 class="card-title">Affichage</h5>
        <p class="card-text">afficher les donnes des stagaires.</p>
        <a href="affichage.php" class="btn btn-primary">Afficher</a>
      </div>
    </div>
  </div>
  
    

</div>



        
    
    
    
</body>
</html>