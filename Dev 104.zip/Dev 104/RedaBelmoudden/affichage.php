<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <?php
        require_once 'database.php';
        include_once 'nav.php';
        $sqlstate=$pdo->query('SELECT * FROM stagaire');
        $donné=$sqlstate->fetchAll(PDO::FETCH_OBJ);

        $where="";
        if(isset($_GET['ok'])){
            $searchhh=$_GET['search'];
            
            
            $search=$pdo->prepare("SELECT * FROM stagaire where nom=? ");
            $search->execute([$searchhh]);
            $result=$search->fetch(PDO::FETCH_OBJ);
            var_dump($result);
        }
       
        
       
        

    
    ?>
    <form class="d-flex" method="GET">
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search" name="search">
        <input type="submit"  class="btn-primary"  value="search" name="ok">
      </form>



   
    <table class="table table-striped   mt-2">
  
  <tr>
    <th scope="col">id</th>
    <th scope="col">nom</th>
    <th scope="col">prenom</th>
    <th scope="col">note</th>
    <th scope="col">resultat</th>
    <th scope="col"> modifier </th>
    <th scope="col"> supprimer </th>
  </tr>



<?php 

    foreach($donné as $donnéé){ ?>
       <tr>
                      <td><?= $donnéé->id ?> </td>
                      <td><?= $donnéé->nom ?> </td>
                      <td><?= $donnéé->prenom ?> </td>
                      <td><?= $donnéé->note ?> </td>
                      <td><?= $donnéé->resultat ?> </td>
                      <td style="width: 10%;"><form action="modifier.php" method="POST" class="form-control">
                        <input type="hidden" name="id" value="<?= $donnéé->id ?>">
                        <input type="submit" value="modifier" class="form-control no-border btn btn-primary"name="modifier">
                      </form>
                    </td>
                    <td style="width:10% ;"><form action="supprimer.php" method="POST" class="form-control">
                        <input type="hidden" name="id" value="<?= $donnéé->id ?>">
                        <input type="submit" value="Suprimer" class="form-control no-border btn btn-danger"name="Suprimer">
                      </form></td>
                      <?php 
    };
  ?>
  </tr>

</table>
</body>
</html>