<?php 
$pdoUsers=new PDO('mysql:host=localhost;dbname=project','root','zbiba2996')
?>