<?php 
    if(!isset($_POST['id'])){
        header('location:index.php');
    }

    require_once 'database.php';
    $id = $_POST['id'];
    $sqlState = $pdo->prepare("DELETE FROM meuble WHERE id=?");
    $result = $sqlState->execute([$id]);

    if($result==true){
        header('location:index.php');
    }
?>