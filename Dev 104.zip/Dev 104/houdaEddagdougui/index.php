<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
    <title>Document</title>
</head>
<body>
    <?php
    require_once 'database.php';
    require_once 'nav.php';

    $sqlState = $pdo->prepare('SELECT * FROM meuble ORDER BY enStock DESC');
    $sqlState->execute();
    $meubles = $sqlState->fetchAll(PDO::FETCH_OBJ);
    $countSqlState = $pdo->query("SELECT COUNT(*) AS 'count' FROM meuble");
    $count = $countSqlState->fetch(PDO::FETCH_OBJ);
    ?>
    <section class="container">
        <h2 class='h2 text-center my-4'>Les Meubles</h2>
        <div class="row my-4 card-group">
            <?php
            foreach($meubles as $meuble){
            ?>
                <div class="col-sm-4">
                    <div class="card">
                        <?php
                        if(!empty($meuble->image)){
                        ?>
                            <img class="card-img-top" src="image/meubles/<?php echo $meuble->image ?>" >
                            <?php
                            } else {
                        ?>
                                <img src="image/logo.png" class="card-img-top">
                        <?php
                        }
                        ?>
                        <div class="card-body">
                            <h5 class="card-title fw-bold text-center"><?php echo $meuble->libelle ?></h5> <small>(#<?php echo $meuble->id?>)</small></h5>
                            <p class="card-text text-center"><?php echo $meuble->descriptions ?></p>
                            <div class="badges my-3">
                                <span class="badge rounded-pill bg-primary"><?php echo number_format($meuble->prix,2) ?> DH</span>

                                <?php
                                $enStock = $meuble->enStock;
                                if($enStock == 1) {
                                ?>
                                    <span class="badge rounded-pill bg-success float-end">En Stock</span>
                                <?php
                                } else {
                                ?><span class="badge rounded-pill bg-warning float-end">En Rupture De Stock</span>
                                <?php
                                }
                                ?>
                                <div class="card-footer my-4">
                                    <form method="post">
                                        <input type="hidden" class="form-control" name="id" value="<?php echo $meuble->id ?>">
                                        <input  class="btn btn-info w-100 my-2" type="submit" value="Modifier" formaction="modifier.php">
                                        <input type="submit" class="btn btn-danger w-100" value="Supprimer"  formaction="supprimer.php" onclick="return confirm('Voulez vous vraiment supprimer ce meuble')">
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php
            }
            ?>
        </div>
    </section>
</body>

</html>