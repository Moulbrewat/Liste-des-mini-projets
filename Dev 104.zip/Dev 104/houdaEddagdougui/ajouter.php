<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
    <title>Document</title>
</head>
<body>
    <?php
    require_once 'nav.php';
    ?>
<section class="container">
        <h1 class='h3 text-center my-4'>Ajouter Meubles</h1>
        <form method="POST" class="form my-5 border p-2 w-75 mx-auto" enctype="multipart/form-data">
            <?php 
                if(isset($_POST['ajouter'])){
                    $libelle = $_POST['libelle'];
                    $description = $_POST['description'];
                    $prix = $_POST['prix'];
                    $enStock = @$_POST['enStock'];
                    $image ='';
                    $imageFile =$_FILES['image'];
                    $imageFileName = time().basename($imageFile['name']);

                    if(!empty($imageFileName)){
                        move_uploaded_file($imageFile['tmp_name'],'image/meubles/'.$imageFileName);
                    }

                    if(!empty($libelle) && !empty($description) && !empty($prix)){
                       
                        $enStock = !empty($enStock)?true:false;

                        require_once 'database.php';
                        $sqlState = $pdo->prepare("INSERT INTO meuble VALUES(null,?,?,?,?,?)");
                        $result = $sqlState->execute([
                            $libelle,
                            $description,
                            $prix,
                            $enStock,
                            $imageFileName
                            ]);
                        if($result === true){
                            header('location:index.php');
                        }
                    }else{
                        ?>
                        <div class="alert alert-danger" role="alert">
                            <h2>Erreur : </h2>
                            Tous les champs sont obligatoires !! 
                        </div>
                        <?php
                    }
                }
            ?>
            <div class="mb-3">
                <label class="form-label">Title</label>
                <input type="text" name="libelle" class="form-control" placeholder="Libelle de meuble.">
            </div>
            <div class="mb-3">
                <label class="form-label">Description</label>
                <textarea name="description" class="form-control" placeholder="Description de meuble."></textarea>
            </div>
            <div class="mb-3">
                <label class="form-label">Price</label>
                <input type="number" name="prix" class="form-control" placeholder="Prix de meuble.">
            </div>
            <div class="form-check form-switch mb-3">
                <input class="form-check-input" type="checkbox" name="enStock">
                <label class="form-check-label">En stock</label>
            </div>
            <div class="mb-3">
                <label class="form-label">Image</label>
                <input class="form-control form-control-sm" type="file" name="image">
            </div>
            <input type="submit" class="btn btn-primary w-100" value="Ajouter" name="ajouter">
        </form>
    </section>
</body>
</html>