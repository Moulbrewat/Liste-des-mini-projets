<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
    <title>Connexion</title>
</head>

<body>
<div class="container mt-5">

<a href="signUp.php" class="btn btn-success">Sign-up</a>

<h1 class='h3 text-center my-4'>Connexion</h1>
    <form method="POST" class="form my-5 border p-2 w-75 mx-auto" enctype="multipart/form-data">
        <?php
        require_once 'database.php';

        if (isset($_POST['connexion'])) {
            $login = $_POST['login'];
            $password = $_POST['password'];
            if (!empty($login) && !empty($password)) {

                $sqlState = $pdo->prepare('SELECT * FROM connexion WHERE login=? AND password=?');
                $sqlState->execute([$login, $password]);
                $count = $sqlState->rowCount();
                if ($count >= 1) {

                    $data = $sqlState->fetch(PDO::FETCH_ASSOC);

                    $_SESSION['user'] = $data;


                    header('location: index.php');
                } else {
        ?>
                    <div class="alert alert-danger" role="alert">
                        <h2>Erreur : </h2>
                        Login ou mot de passe incorrect.
                    </div>
                <?php
                }
            } else {
                ?>
                <div class="alert alert-danger" role="alert">
                    <h2>Erreur : </h2>
                    Tous les champs sont obligatoires !!
                </div>
                }<?php
                }
            }
                    ?>
                <div class="mb-3">
                    <label class="form-label">Login</label>
                    <input type="text" name="login" class="form-control" placeholder="Login">
                </div>
                <div class="mb-3">
                    <label class="form-label">Mot de passe</label>
                    <input type="password" name="password" class="form-control" placeholder="Mot de passe">
                </div>
                <input type="submit" class="btn btn-primary w-100" value="Connexion" name="connexion">
    </form>
    </div>
</body>

</html>