<?php 
 try{
    $pdo = new PDO('mysql:host=localhost;dbname=meubles','root','');
 }catch(\PDOException $e){
    echo $e->getMessage();
 }
 ?>