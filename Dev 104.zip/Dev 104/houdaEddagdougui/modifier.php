<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
    <title>Document</title>
</head>
<body>
    <?php
        require_once 'nav.php';
    ?>
<form method="POST" class="form my-5 border p-2 w-75 mx-auto" enctype="multipart/form-data">
<?php 
        if(!isset($_POST['id'])){
            header('location: index.php');
        }
        require_once 'database.php';

        $id = $_POST['id'];
        $sqlState = $pdo->prepare('SELECT * FROM meuble WHERE id=?');
        $sqlState->execute([$id]);
        $meuble = $sqlState->fetch(PDO::FETCH_OBJ);
        if(isset($_POST['modifier0'])){
            $libelle = $_POST['libelle'];
            $description = $_POST['description'];
            $prix = $_POST['prix'];
            $id = $_POST['id'];
            if(!empty($id) && !empty($libelle) && !empty($description) && !empty($prix)){
                $sqlState = $pdo->prepare('UPDATE meuble  SET libelle=?, descriptions=?, prix=? WHERE id=?');
                $result = $sqlState->execute([$libelle,$description,$prix,$id]);
                if($result == true){
                    header('location:index.php');
                }
            }else{
                ?>
                 <div class="alert alert-danger" role="alert">
                    <span class='fw-bolder'>Tout les champs sont obligatoires</span>
                    </div>
                <?php
            }
        }
    ?>

    <input type="hidden" name="id" value="<?php echo $meuble->id?>">
    <div class="mb-3">
                <label class="form-label">Libelle</label>
                <input type="text" name="libelle" class="form-control" value="<?php echo $meuble->libelle?>">
            </div>
            <div class="mb-3">
                <label class="form-label">Description</label>
                <textarea name="description" class="form-control" value="<?php echo $meuble->descriptions?>"></textarea>
            </div>
            <div class="mb-3">
                <label class="form-label">Prix</label>
                <input type="number" name="prix" class="form-control" value="<?php echo $meuble->prix?>">
            </div>
            <input type="submit" class="btn btn-primary w-100" value="Modifier" name="modifier0">
        </form>
</body>
</html>


